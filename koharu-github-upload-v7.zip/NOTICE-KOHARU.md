Koharu Client is a modified version of Marlowww Client 5.5-1.21.11
(https://github.com/nxghtCry0/marlowwwclient, GPL-3.0).
Modifications: rebrand (mod id koharuclient, package com.koharu.koharuclient, class/asset names, display name).
All original copyright notices and the GPL-3.0 license are retained.
