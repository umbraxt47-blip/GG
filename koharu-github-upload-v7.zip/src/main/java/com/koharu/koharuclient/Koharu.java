package com.koharu.koharuclient;

import net.fabricmc.api.ModInitializer;

public class Koharu implements ModInitializer {

    @Override
    public void onInitialize() {
    }
}
