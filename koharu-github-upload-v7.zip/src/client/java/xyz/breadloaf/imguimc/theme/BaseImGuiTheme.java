package xyz.breadloaf.imguimc.theme;

import imgui.ImGui;
import imgui.ImGuiIO;
import imgui.ImGuiStyle;
import imgui.flag.ImGuiCol;

final class BaseImGuiTheme {

    private BaseImGuiTheme() {
    }

    static void applyClassic() {
        ImGuiStyle style = ImGui.getStyle();
        applyLayout(style);
        applyDarkColors(style, 150, 105, 255, 225, 95, 205);
    }

    static void applyDark() {
        ImGuiStyle style = ImGui.getStyle();
        applyLayout(style);
        applyDarkColors(style, 185, 125, 255, 245, 110, 205);
    }

    static void applyLight() {
        ImGuiStyle style = ImGui.getStyle();
        applyLayout(style);

        style.setColor(ImGuiCol.Text, 30, 27, 42, 255);
        style.setColor(ImGuiCol.TextDisabled, 104, 96, 120, 230);
        style.setColor(ImGuiCol.WindowBg, 250, 248, 255, 252);
        style.setColor(ImGuiCol.ChildBg, 255, 255, 255, 245);
        style.setColor(ImGuiCol.PopupBg, 255, 255, 255, 250);
        style.setColor(ImGuiCol.Border, 112, 96, 140, 78);
        style.setColor(ImGuiCol.BorderShadow, 0, 0, 0, 0);
        style.setColor(ImGuiCol.FrameBg, 247, 244, 255, 255);
        style.setColor(ImGuiCol.FrameBgHovered, 232, 224, 255, 255);
        style.setColor(ImGuiCol.FrameBgActive, 218, 205, 255, 255);
        style.setColor(ImGuiCol.TitleBg, 238, 233, 249, 255);
        style.setColor(ImGuiCol.TitleBgActive, 229, 222, 247, 255);
        style.setColor(ImGuiCol.TitleBgCollapsed, 238, 233, 249, 240);
        style.setColor(ImGuiCol.MenuBarBg, 240, 236, 249, 252);
        style.setColor(ImGuiCol.ScrollbarBg, 78, 60, 110, 24);
        style.setColor(ImGuiCol.ScrollbarGrab, 108, 82, 160, 105);
        style.setColor(ImGuiCol.ScrollbarGrabHovered, 136, 88, 220, 150);
        style.setColor(ImGuiCol.ScrollbarGrabActive, 176, 96, 210, 190);
        style.setColor(ImGuiCol.CheckMark, 118, 72, 210, 255);
        style.setColor(ImGuiCol.SliderGrab, 118, 72, 210, 230);
        style.setColor(ImGuiCol.SliderGrabActive, 190, 82, 185, 255);
        style.setColor(ImGuiCol.Button, 232, 224, 255, 255);
        style.setColor(ImGuiCol.ButtonHovered, 218, 205, 255, 255);
        style.setColor(ImGuiCol.ButtonActive, 204, 188, 250, 255);
        style.setColor(ImGuiCol.Header, 239, 234, 252, 255);
        style.setColor(ImGuiCol.HeaderHovered, 224, 214, 255, 255);
        style.setColor(ImGuiCol.HeaderActive, 211, 196, 252, 255);
        style.setColor(ImGuiCol.Separator, 112, 96, 140, 68);
        style.setColor(ImGuiCol.SeparatorHovered, 136, 88, 220, 150);
        style.setColor(ImGuiCol.SeparatorActive, 190, 82, 185, 190);
        style.setColor(ImGuiCol.ResizeGrip, 136, 88, 220, 82);
        style.setColor(ImGuiCol.ResizeGripHovered, 136, 88, 220, 132);
        style.setColor(ImGuiCol.ResizeGripActive, 190, 82, 185, 175);
        style.setColor(ImGuiCol.Tab, 239, 235, 249, 255);
        style.setColor(ImGuiCol.TabHovered, 222, 211, 255, 255);
        style.setColor(ImGuiCol.TabActive, 213, 199, 250, 255);
        style.setColor(ImGuiCol.TabUnfocused, 232, 228, 241, 240);
        style.setColor(ImGuiCol.TabUnfocusedActive, 224, 214, 248, 255);
        style.setColor(ImGuiCol.DockingPreview, 136, 88, 220, 150);
        style.setColor(ImGuiCol.DockingEmptyBg, 240, 236, 249, 230);
        style.setColor(ImGuiCol.PlotLines, 118, 72, 210, 230);
        style.setColor(ImGuiCol.PlotLinesHovered, 190, 82, 185, 255);
        style.setColor(ImGuiCol.PlotHistogram, 118, 72, 210, 220);
        style.setColor(ImGuiCol.PlotHistogramHovered, 190, 82, 185, 250);
        style.setColor(ImGuiCol.TableHeaderBg, 239, 235, 249, 255);
        style.setColor(ImGuiCol.TableBorderStrong, 112, 96, 140, 82);
        style.setColor(ImGuiCol.TableBorderLight, 112, 96, 140, 48);
        style.setColor(ImGuiCol.TableRowBg, 255, 255, 255, 0);
        style.setColor(ImGuiCol.TableRowBgAlt, 80, 58, 120, 16);
        style.setColor(ImGuiCol.TextSelectedBg, 136, 88, 220, 96);
        style.setColor(ImGuiCol.DragDropTarget, 190, 82, 185, 210);
        style.setColor(ImGuiCol.NavHighlight, 136, 88, 220, 170);
        style.setColor(ImGuiCol.NavWindowingHighlight, 255, 255, 255, 180);
        style.setColor(ImGuiCol.NavWindowingDimBg, 24, 28, 36, 72);
        style.setColor(ImGuiCol.ModalWindowDimBg, 24, 28, 36, 120);
    }

    private static void applyLayout(ImGuiStyle style) {
        float scale = getScale();

        style.setAlpha(1.0f);
        style.setDisabledAlpha(0.58f);
        style.setWindowPadding(12f * scale, 10f * scale);
        style.setFramePadding(8f * scale, 5f * scale);
        style.setCellPadding(5f * scale, 4f * scale);
        style.setItemSpacing(8f * scale, 6f * scale);
        style.setItemInnerSpacing(6f * scale, 4f * scale);
        style.setIndentSpacing(14f * scale);
        style.setScrollbarSize(12f * scale);
        style.setGrabMinSize(10f * scale);
        style.setWindowRounding(10f * scale);
        style.setChildRounding(8f * scale);
        style.setFrameRounding(6f * scale);
        style.setPopupRounding(8f * scale);
        style.setScrollbarRounding(8f * scale);
        style.setGrabRounding(6f * scale);
        style.setTabRounding(6f * scale);
        style.setWindowBorderSize(1f * scale);
        style.setChildBorderSize(1f * scale);
        style.setPopupBorderSize(1f * scale);
        style.setFrameBorderSize(0f);
        style.setTabBorderSize(0f);
        style.setWindowTitleAlign(0.5f, 0.5f);
        style.setAntiAliasedLines(true);
        style.setAntiAliasedFill(true);
    }

    private static void applyDarkColors(ImGuiStyle style, int accentRed, int accentGreen, int accentBlue, int glowRed, int glowGreen, int glowBlue) {
        style.setColor(ImGuiCol.Text, 238, 243, 255, 255);
        style.setColor(ImGuiCol.TextDisabled, 140, 140, 155, 215);
        style.setColor(ImGuiCol.WindowBg, 13, 17, 33, 245);
        style.setColor(ImGuiCol.ChildBg, 19, 24, 46, 240);
        style.setColor(ImGuiCol.PopupBg, 16, 20, 40, 248);
        style.setColor(ImGuiCol.Border, 56, 66, 108, 120);
        style.setColor(ImGuiCol.BorderShadow, 0, 0, 0, 0);
        style.setColor(ImGuiCol.FrameBg, 27, 33, 60, 220);
        style.setColor(ImGuiCol.FrameBgHovered, 40, 48, 82, 240);
        style.setColor(ImGuiCol.FrameBgActive, 214, 56, 84, 255);
        style.setColor(ImGuiCol.TitleBg, 13, 17, 33, 255);
        style.setColor(ImGuiCol.TitleBgActive, 19, 24, 46, 255);
        style.setColor(ImGuiCol.TitleBgCollapsed, 13, 17, 33, 235);
        style.setColor(ImGuiCol.MenuBarBg, 19, 24, 46, 245);
        style.setColor(ImGuiCol.ScrollbarBg, 8, 10, 22, 80);
        style.setColor(ImGuiCol.ScrollbarGrab, 214, 56, 84, 160);
        style.setColor(ImGuiCol.ScrollbarGrabHovered, 214, 56, 84, 210);
        style.setColor(ImGuiCol.ScrollbarGrabActive, 240, 84, 110, 255);
        style.setColor(ImGuiCol.CheckMark, 214, 56, 84, 255);
        style.setColor(ImGuiCol.SliderGrab, 214, 56, 84, 255);
        style.setColor(ImGuiCol.SliderGrabActive, 240, 84, 110, 255);
        style.setColor(ImGuiCol.Button, 27, 33, 60, 200);
        style.setColor(ImGuiCol.ButtonHovered, 40, 48, 82, 240);
        style.setColor(ImGuiCol.ButtonActive, 214, 56, 84, 255);
        style.setColor(ImGuiCol.Header, 27, 33, 60, 180);
        style.setColor(ImGuiCol.HeaderHovered, 40, 48, 82, 220);
        style.setColor(ImGuiCol.HeaderActive, 214, 56, 84, 255);
        style.setColor(ImGuiCol.Separator, 56, 66, 108, 100);
        style.setColor(ImGuiCol.SeparatorHovered, 214, 56, 84, 180);
        style.setColor(ImGuiCol.SeparatorActive, 240, 84, 110, 230);
        style.setColor(ImGuiCol.ResizeGrip, 214, 56, 84, 100);
        style.setColor(ImGuiCol.ResizeGripHovered, 214, 56, 84, 180);
        style.setColor(ImGuiCol.ResizeGripActive, 240, 84, 110, 230);
        style.setColor(ImGuiCol.Tab, 19, 24, 46, 245);
        style.setColor(ImGuiCol.TabHovered, 40, 48, 82, 240);
        style.setColor(ImGuiCol.TabActive, 214, 56, 84, 255);
        style.setColor(ImGuiCol.TabUnfocused, 13, 17, 33, 220);
        style.setColor(ImGuiCol.TabUnfocusedActive, 214, 56, 84, 180);
        style.setColor(ImGuiCol.DockingPreview, 214, 56, 84, 160);
        style.setColor(ImGuiCol.DockingEmptyBg, 13, 17, 33, 230);
        style.setColor(ImGuiCol.PlotLines, 214, 56, 84, 230);
        style.setColor(ImGuiCol.PlotLinesHovered, 240, 84, 110, 255);
        style.setColor(ImGuiCol.PlotHistogram, 214, 56, 84, 220);
        style.setColor(ImGuiCol.PlotHistogramHovered, 240, 84, 110, 250);
        style.setColor(ImGuiCol.TableHeaderBg, 23, 29, 54, 245);
        style.setColor(ImGuiCol.TableBorderStrong, 56, 66, 108, 120);
        style.setColor(ImGuiCol.TableBorderLight, 56, 66, 108, 60);
        style.setColor(ImGuiCol.TableRowBg, 255, 255, 255, 0);
        style.setColor(ImGuiCol.TableRowBgAlt, 255, 255, 255, 18);
        style.setColor(ImGuiCol.TextSelectedBg, 214, 56, 84, 120);
        style.setColor(ImGuiCol.DragDropTarget, 240, 84, 110, 220);
        style.setColor(ImGuiCol.NavHighlight, 214, 56, 84, 190);
        style.setColor(ImGuiCol.NavWindowingHighlight, 255, 255, 255, 200);
        style.setColor(ImGuiCol.NavWindowingDimBg, 0, 0, 0, 90);
        style.setColor(ImGuiCol.ModalWindowDimBg, 0, 0, 0, 120);
    }

    private static float getScale() {
        ImGuiIO io = ImGui.getIO();
        float scale = Math.max(io.getDisplayFramebufferScaleX(), io.getDisplayFramebufferScaleY());

        if (!Float.isFinite(scale) || scale < 1.0f)
            return 1.0f;

        return scale;
    }
}
