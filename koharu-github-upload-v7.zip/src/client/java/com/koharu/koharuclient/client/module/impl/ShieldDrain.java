package com.koharu.koharuclient.client.module.impl;

import com.koharu.koharuclient.client.KoharuClient;
import com.koharu.koharuclient.client.module.Category;
import com.koharu.koharuclient.client.module.Module;
import com.koharu.koharuclient.client.setting.Setting;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;

public class ShieldDrain extends Module {
    private double attackDebt = 0.0;
    private long lastGuiTime = 0;

    public ShieldDrain() {
        super("ShieldDrain", Category.Utility, "Massively inflates CPS against shielding enemies to break/drain their shield.");
        KoharuClient.INSTANCE.settingsManager.rSetting(new Setting("CPS", this, 90.0, 20.0, 200.0, true));
        KoharuClient.INSTANCE.settingsManager.rSetting(new Setting("Range", this, 4.0, 1.0, 6.0, false));
        KoharuClient.INSTANCE.settingsManager.rSetting(new Setting("Legit Mode", this, true));
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.level == null) return;

        if (mc.screen != null) {
            lastGuiTime = System.currentTimeMillis();
        }

        Setting legitSetting = KoharuClient.INSTANCE.settingsManager.getSettingByName(this, "Legit Mode");
        if (legitSetting != null && legitSetting.getValBoolean()) {
            if (mc.screen != null) {
                attackDebt = 0.0;
                return;
            }
            if (System.currentTimeMillis() - lastGuiTime < 3000) {
                attackDebt = 0.0;
                return;
            }
        }

        Setting cpsSetting = KoharuClient.INSTANCE.settingsManager.getSettingByName(this, "CPS");
        Setting rangeSetting = KoharuClient.INSTANCE.settingsManager.getSettingByName(this, "Range");

        double cps = cpsSetting != null ? cpsSetting.getValDouble() : 90.0;
        double range = rangeSetting != null ? rangeSetting.getValDouble() : 4.0;

        Player bestTarget = null;
        double bestDist = range + 0.1;

        for (Entity entity : mc.level.entitiesForRendering()) {
            if (entity instanceof Player target && target != mc.player && target.isAlive()) {
                double dist = mc.player.distanceTo(target);
                if (dist <= range && target.isBlocking()) {
                    if (dist < bestDist) {
                        bestDist = dist;
                        bestTarget = target;
                    }
                }
            }
        }

        if (bestTarget != null) {
            double attacksPerTick = cps / 20.0;
            attackDebt += attacksPerTick;

            int attacksThisTick = (int) attackDebt;
            if (attacksThisTick > 0) {
                for (int i = 0; i < attacksThisTick; i++) {
                    mc.gameMode.attack(mc.player, bestTarget);
                    com.koharu.koharuclient.client.utils.ModuleUtils.attackSwing();
                }
                attackDebt -= attacksThisTick;
            }
        } else {
            attackDebt = 0.0;
        }
    }
}
