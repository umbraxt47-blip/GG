package com.koharu.koharuclient.client.module.impl;

import com.koharu.koharuclient.client.module.Category;
import com.koharu.koharuclient.client.module.Module;

public class NoParticles extends Module {
    public NoParticles() {
        super("NoParticles", Category.Render, "Disables all client particle rendering.");
    }
}

