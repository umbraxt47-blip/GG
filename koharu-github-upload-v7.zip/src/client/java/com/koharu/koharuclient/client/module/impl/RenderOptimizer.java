package com.koharu.koharuclient.client.module.impl;

import com.koharu.koharuclient.client.KoharuClient;
import com.koharu.koharuclient.client.module.Category;
import com.koharu.koharuclient.client.module.Module;
import com.koharu.koharuclient.client.setting.Setting;

public class RenderOptimizer extends Module {
    public static RenderOptimizer INSTANCE;

    public RenderOptimizer() {
        super("RenderOptimizer", Category.Render, "Optimizes standard UI rendering and overlays.");
        INSTANCE = this;
        
        KoharuClient.INSTANCE.settingsManager.rSetting(new Setting("No Scoreboard", this, true));
        KoharuClient.INSTANCE.settingsManager.rSetting(new Setting("No Hurt Cam", this, true));
        KoharuClient.INSTANCE.settingsManager.rSetting(new Setting("No Bobbing", this, true));
        KoharuClient.INSTANCE.settingsManager.rSetting(new Setting("Low Fire", this, true));
        KoharuClient.INSTANCE.settingsManager.rSetting(new Setting("Low Shield", this, true));
        KoharuClient.INSTANCE.settingsManager.rSetting(new Setting("Low Totem", this, true));
        KoharuClient.INSTANCE.settingsManager.rSetting(new Setting("Fast Totem Anim", this, true));
    }

    @Override
    public void onTick() {
        if (!isToggled() || mc.player == null) return;
        
        Setting noBob = KoharuClient.INSTANCE.settingsManager.getSettingByName(this, "No Bobbing");
        if (noBob != null && noBob.getValBoolean()) {
            if (mc.options.bobView().get()) {
                mc.options.bobView().set(false);
            }
        }
    }
}
