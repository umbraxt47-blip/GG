package com.koharu.koharuclient.client.module.impl;

import com.koharu.koharuclient.client.module.Category;
import com.koharu.koharuclient.client.module.Module;

public class LegacyUI extends Module {
    public static LegacyUI INSTANCE;

    public LegacyUI() {
        super("LegacyUI", Category.Client, "Enables the old click GUI instead of the new glassy UI.");
        INSTANCE = this;
    }
}
