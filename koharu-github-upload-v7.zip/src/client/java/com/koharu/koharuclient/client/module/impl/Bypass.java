package com.koharu.koharuclient.client.module.impl;

import com.koharu.koharuclient.client.KoharuClient;
import com.koharu.koharuclient.client.module.Category;
import com.koharu.koharuclient.client.module.Module;
import com.koharu.koharuclient.client.setting.Setting;

public class Bypass extends Module {
    public Bypass() {
        super("Bypass", Category.Client, "Hides visuals and makes GUI require looking down + 5s hold.");
        KoharuClient.INSTANCE.settingsManager.rSetting(new Setting("Disable Command Autofill", this, false));
    }
}
