package com.koharu.koharuclient.client.module.impl;

import com.koharu.koharuclient.client.KoharuClient;
import com.koharu.koharuclient.client.module.Category;
import com.koharu.koharuclient.client.module.Module;
import com.koharu.koharuclient.client.setting.Setting;
import com.koharu.koharuclient.client.utils.ModuleUtils;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;

import java.util.List;

/**
 * Hold right click while aiming at a block:
 *  - aimed block is not obsidian/bedrock  -> places obsidian next to it
 *  - obsidian/bedrock with free top       -> places a crystal on it
 *  - crystal is there                     -> hits it
 * and repeats, at an adjustable actions-per-second rate.
 */
public class CrystalMacro extends Module {
    private static final int MAX_ACTIONS_PER_TICK = 30;

    private final Setting cps;
    private final Setting range;
    private final Setting useObsidian;
    private final Setting useOffhand;

    private double budget = 0.0;
    private BlockPos base = null;

    public CrystalMacro() {
        super("CrystalMacro", Category.Crystal,
                "Hold right click: auto obsidian -> crystal -> hit, with swappable item and adjustable CPS.");

        cps = new Setting("CPS", this, 20, 1, 500, true);
        range = new Setting("Range", this, 4.5, 1.0, 6.0, false);
        useObsidian = new Setting("Place Obsidian", this, true);
        useOffhand = new Setting("Prefer Offhand Crystal", this, true);

        KoharuClient.INSTANCE.settingsManager.rSetting(cps);
        KoharuClient.INSTANCE.settingsManager.rSetting(range);
        KoharuClient.INSTANCE.settingsManager.rSetting(useObsidian);
        KoharuClient.INSTANCE.settingsManager.rSetting(useOffhand);
    }

    @Override
    public void onDisable() {
        budget = 0.0;
        base = null;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.level == null || mc.gameMode == null) return;
        if (mc.screen != null || !mc.options.keyUse.isDown()) {
            budget = 0.0;
            base = null;
            return;
        }

        budget += cps.getValDouble() / 20.0;
        int actions = Math.min((int) budget, MAX_ACTIONS_PER_TICK);
        budget -= (int) budget;

        retarget(actions > 0);

        for (int i = 0; i < actions; i++) {
            if (!step()) break;
        }
    }

    /** Pick the obsidian/bedrock we work on from what the crosshair points at. */
    private void retarget(boolean mayPlaceObsidian) {
        HitResult hit = mc.hitResult;
        if (hit instanceof BlockHitResult bhr && hit.getType() == HitResult.Type.BLOCK) {
            BlockPos pos = bhr.getBlockPos();
            if (isCrystallable(pos)) {
                base = pos;
            } else if (base == null || !isCrystallable(base)) {
                // not obsidian under the crosshair: build one next to it
                if (mayPlaceObsidian && useObsidian.getValBoolean()) {
                    BlockPos target = pos.relative(bhr.getDirection());
                    if (placeObsidian(bhr, target)) base = target;
                }
            }
        } else if (hit instanceof EntityHitResult ehr && ehr.getEntity() instanceof EndCrystal c) {
            BlockPos below = c.blockPosition().below();
            if (isCrystallable(below)) base = below;
        }
        if (base != null && !inReach(Vec3.atCenterOf(base))) base = null;
    }

    /** One action. Returns false when there is nothing useful to do. */
    private boolean step() {
        if (base == null || !isCrystallable(base)) return false;

        EndCrystal crystal = crystalAbove(base);
        if (crystal != null) {
            mc.gameMode.attack(mc.player, crystal);
            mc.player.swing(InteractionHand.MAIN_HAND);
            return true;
        }
        if (topIsFree(base)) {
            return placeCrystal(base);
        }
        return false;
    }

    // ------------------------------------------------------------ helpers

    private boolean isCrystallable(BlockPos pos) {
        BlockState st = mc.level.getBlockState(pos);
        return st.is(Blocks.OBSIDIAN) || st.is(Blocks.BEDROCK);
    }

    private boolean inReach(Vec3 point) {
        double r = range.getValDouble();
        return mc.player.getEyePosition().distanceToSqr(point) <= r * r;
    }

    private EndCrystal crystalAbove(BlockPos pos) {
        AABB box = new AABB(pos.above()).expandTowards(0, 1, 0);
        List<EndCrystal> list = mc.level.getEntitiesOfClass(EndCrystal.class, box);
        for (EndCrystal c : list) {
            if (c.isAlive() && c.getBoundingBox().distanceToSqr(mc.player.getEyePosition())
                    <= range.getValDouble() * range.getValDouble()) {
                return c;
            }
        }
        return null;
    }

    private boolean topIsFree(BlockPos pos) {
        BlockPos above = pos.above();
        if (!mc.level.isEmptyBlock(above)) return false;
        AABB column = new AABB(above).expandTowards(0, 1, 0);
        return mc.level.getEntities((net.minecraft.world.entity.Entity) null, column).isEmpty();
    }

    private boolean placeCrystal(BlockPos pos) {
        BlockHitResult hit = new BlockHitResult(
                new Vec3(pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5), Direction.UP, pos, false);

        if (useOffhand.getValBoolean() && mc.player.getOffhandItem().is(Items.END_CRYSTAL)) {
            mc.gameMode.useItemOn(mc.player, InteractionHand.OFF_HAND, hit);
            mc.player.swing(InteractionHand.OFF_HAND);
            return true;
        }
        int slot = ModuleUtils.getCrystalSlot();
        if (slot == -1) return false;
        ModuleUtils.runSilentSwap(slot, () -> {
            mc.gameMode.useItemOn(mc.player, InteractionHand.MAIN_HAND, hit);
            mc.player.swing(InteractionHand.MAIN_HAND);
        });
        return true;
    }

    private boolean placeObsidian(BlockHitResult clicked, BlockPos target) {
        if (!mc.level.getBlockState(target).canBeReplaced()) return false;
        if (!mc.level.isUnobstructed(Blocks.OBSIDIAN.defaultBlockState(), target, CollisionContext.empty())) return false;
        if (!inReach(Vec3.atCenterOf(target))) return false;
        int slot = ModuleUtils.getObsidianSlot();
        if (slot == -1) return false;
        ModuleUtils.runSilentSwap(slot, () -> {
            mc.gameMode.useItemOn(mc.player, InteractionHand.MAIN_HAND, clicked);
            mc.player.swing(InteractionHand.MAIN_HAND);
        });
        return true;
    }
}
