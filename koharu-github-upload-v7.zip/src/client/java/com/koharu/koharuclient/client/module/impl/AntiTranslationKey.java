package com.koharu.koharuclient.client.module.impl;

import com.koharu.koharuclient.client.module.Category;
import com.koharu.koharuclient.client.module.Module;

public class AntiTranslationKey extends Module {
    public AntiTranslationKey() {
        super("AntiTranslationKey", Category.Misc, "Prevents servers from crashing you with malformed translation strings.");
    }
}