package com.koharu.koharuclient.client.clickgui;

import com.koharu.koharuclient.client.module.Category;



/* Location:              C:\Users\teeja\Downloads\koharuclient-v4-beta-2-v4-beta.jar!\com\koharu\koharuclient\client\clickgui\KoharuGUI$1.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */