package com.koharu.koharuclient.client.module.impl;

import com.koharu.koharuclient.client.KoharuClient;
import com.koharu.koharuclient.client.module.Category;
import com.koharu.koharuclient.client.module.Module;
import com.koharu.koharuclient.client.setting.Setting;
import com.koharu.koharuclient.client.utils.ModuleUtils;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;

public class AutoShieldBreaker extends Module {
    public long lastBreakTime = 0;
    private boolean needsSwapBack = false;
    private long swapBackTime = 0;
    private int originalSlot = -1;
    private int axeSlot = -1;
    private int ticksWaited = 0;

    private boolean pendingStunAttack = false;
    private Entity stunTarget = null;
    private long stunAttackTime = 0;

    public AutoShieldBreaker() {
        super("AutoShieldBreaker", Category.Combat);
    }

    public boolean shouldCancelAttack(Entity target) {
        if (!this.isToggled() || !(target instanceof LivingEntity)) return false;
        LivingEntity livingTarget = (LivingEntity) target;
        if (!livingTarget.isBlocking()) return false;
        if (!isShieldBlockingUs(livingTarget, mc.player)) return false;
        if (!isHoldingSword(mc.player)) return false;

        Setting delaySetting = KoharuClient.INSTANCE.settingsManager.getSettingByName(this, "Delay (ms)");
        long delay = delaySetting != null ? (long) delaySetting.getValDouble() : 0;
        if (System.currentTimeMillis() - lastBreakTime < delay) {
            return false;
        }
        axeSlot = findAxeInHotbar(mc.player);
        if (axeSlot == -1) return false;

        Setting modeSetting = KoharuClient.INSTANCE.settingsManager.getSettingByName(this, "Mode");
        String mode = modeSetting != null ? modeSetting.getValString() : "Swap";
        int oldSlot = mc.player.getInventory().getSelectedSlot();
        if (oldSlot == axeSlot) {
            lastBreakTime = System.currentTimeMillis();
            triggerStun(target);
            return false;
        }
        if (mode.equals("Silent")) {
            ModuleUtils.switchToSlot(axeSlot);
            needsSwapBack = true;
            originalSlot = oldSlot;
            ticksWaited = 0;
            swapBackTime = 0;
            lastBreakTime = System.currentTimeMillis();
            triggerStun(target);
            return false;
        } else {
            ModuleUtils.switchToSlot(axeSlot);
            Setting swapBackSetting = KoharuClient.INSTANCE.settingsManager.getSettingByName(this, "Swap Back");
            if (swapBackSetting != null && swapBackSetting.getValBoolean()) {
                Setting swapDelaySetting = KoharuClient.INSTANCE.settingsManager.getSettingByName(this, "Swap Back Delay (ms)");
                long swapDelay = swapDelaySetting != null ? (long) swapDelaySetting.getValDouble() : 150;
                needsSwapBack = true;
                swapBackTime = System.currentTimeMillis() + swapDelay;
                originalSlot = oldSlot;
            }
            lastBreakTime = System.currentTimeMillis();
            triggerStun(target);
            return false;
        }
    }

    public boolean handleAttack(Entity target, Player player) {
        if (!this.isToggled() || !(target instanceof LivingEntity)) return false;
        LivingEntity livingTarget = (LivingEntity) target;
        if (!livingTarget.isBlocking()) return false;
        if (!isShieldBlockingUs(livingTarget, player)) return false;
        Setting delaySetting = KoharuClient.INSTANCE.settingsManager.getSettingByName(this, "Delay (ms)");
        long delay = delaySetting != null ? (long) delaySetting.getValDouble() : 0;
        if (System.currentTimeMillis() - lastBreakTime < delay) {
            return false;
        }
        axeSlot = findAxeInHotbar(player);
        if (axeSlot == -1) return false;
        Setting modeSetting = KoharuClient.INSTANCE.settingsManager.getSettingByName(this, "Mode");
        String mode = modeSetting != null ? modeSetting.getValString() : "Swap";
        int oldSlot = player.getInventory().getSelectedSlot();
        if (oldSlot == axeSlot) {
            lastBreakTime = System.currentTimeMillis();
            triggerStun(target);
            return false;
        }
        if (mode.equals("Silent")) {
            ModuleUtils.switchToSlot(axeSlot);
            needsSwapBack = true;
            originalSlot = oldSlot;
            ticksWaited = 0;
            swapBackTime = 0;
            lastBreakTime = System.currentTimeMillis();
            triggerStun(target);
            return false;
        } else {
            ModuleUtils.switchToSlot(axeSlot);
            Setting swapBackSetting = KoharuClient.INSTANCE.settingsManager.getSettingByName(this, "Swap Back");
            if (swapBackSetting != null && swapBackSetting.getValBoolean()) {
                Setting swapDelaySetting = KoharuClient.INSTANCE.settingsManager.getSettingByName(this, "Swap Back Delay (ms)");
                long swapDelay = swapDelaySetting != null ? (long) swapDelaySetting.getValDouble() : 150;
                needsSwapBack = true;
                swapBackTime = System.currentTimeMillis() + swapDelay;
                originalSlot = oldSlot;
            }
            lastBreakTime = System.currentTimeMillis();
            triggerStun(target);
            return false;
        }
    }

    private void triggerStun(Entity target) {
        Setting stunSetting = KoharuClient.INSTANCE.settingsManager.getSettingByName(this, "Stun");
        if (stunSetting != null && stunSetting.getValBoolean()) {
            pendingStunAttack = true;
            stunTarget = target;
            Setting hitDelaySetting = KoharuClient.INSTANCE.settingsManager.getSettingByName(this, "Hit Delay");
            double hitDelayVal = 100.0;
            if (hitDelaySetting != null) {
                hitDelayVal = hitDelaySetting.getValDouble();
            }
            stunAttackTime = System.currentTimeMillis() + (long) hitDelayVal;
        }
    }

    @Override
    public void onTick() {
        if (needsSwapBack && mc.player != null && mc.getConnection() != null) {
            if (swapBackTime == 0) {
                ticksWaited++;
                if (ticksWaited >= 1) {
                    ModuleUtils.switchToSlot(originalSlot);
                    needsSwapBack = false;
                    axeSlot = -1;
                }
            } else if (System.currentTimeMillis() >= swapBackTime) {
                ModuleUtils.switchToSlot(originalSlot);
                needsSwapBack = false;
                swapBackTime = 0;
            }
        }

        if (pendingStunAttack && mc.player != null && mc.gameMode != null && stunTarget != null) {
            if (System.currentTimeMillis() >= stunAttackTime) {
                ((com.koharu.koharuclient.mixin.client.MinecraftAccessor) mc).invokeStartAttack();
                mc.player.swing(InteractionHand.MAIN_HAND);
                pendingStunAttack = false;
                stunTarget = null;
            }
        }
    }

    @Override
    public void onDisable() {
        if (needsSwapBack && mc.player != null && mc.getConnection() != null) {
            ModuleUtils.switchToSlot(originalSlot);
        }
        needsSwapBack = false;
        swapBackTime = 0;
        axeSlot = -1;
        pendingStunAttack = false;
        stunTarget = null;
    }

    private int findAxeInHotbar(Player player) {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = player.getInventory().getItem(i);
            if (stack.is(ItemTags.AXES)) {
                return i;
            }
        }
        return -1;
    }

    private boolean isShieldBlockingUs(LivingEntity target, Player player) {
        Vec3 attackerPos = player.position();
        Vec3 defenderPos = target.position();
        Vec3 attackerToDefender = defenderPos.subtract(attackerPos).normalize();
        attackerToDefender = new Vec3(attackerToDefender.x, 0.0, attackerToDefender.z);
        Vec3 defenderLook = target.getViewVector(1.0F);
        defenderLook = new Vec3(defenderLook.x, 0.0, defenderLook.z);
        return attackerToDefender.dot(defenderLook) < 0.0;
    }

    private boolean isHoldingSword(Player player) {
        ItemStack held = player.getMainHandItem();
        return held.is(ItemTags.SWORDS);
    }
}