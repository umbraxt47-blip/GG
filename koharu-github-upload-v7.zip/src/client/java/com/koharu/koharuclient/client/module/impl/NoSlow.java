package com.koharu.koharuclient.client.module.impl;

import com.koharu.koharuclient.client.KoharuClient;
import com.koharu.koharuclient.client.module.Category;
import com.koharu.koharuclient.client.module.Module;
import com.koharu.koharuclient.client.setting.Setting;

public class NoSlow extends Module {
    public NoSlow() {
        super("NoSlow", Category.Movement);
        KoharuClient.INSTANCE.settingsManager.rSetting(new Setting("Multiplier", this, 0.5, 0.5, 0.6, false));
    }
}
