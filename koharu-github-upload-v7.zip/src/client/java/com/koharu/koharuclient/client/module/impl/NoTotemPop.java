package com.koharu.koharuclient.client.module.impl;

import com.koharu.koharuclient.client.module.Category;
import com.koharu.koharuclient.client.module.Module;

public class NoTotemPop extends Module {
    public NoTotemPop() {
        super("NoTotemPop", Category.Render, "Hides totem pop overlay and activation visuals.");
    }
}