package com.koharu.koharuclient.client.module.impl;

import com.koharu.koharuclient.client.module.Category;
import com.koharu.koharuclient.client.module.Module;

public class FastPlace extends Module {
    public static FastPlace INSTANCE;

    public FastPlace() {
        super("FastPlace", Category.World, "Removes the right-click delay for placing blocks.");
        INSTANCE = this;
    }
}