package com.koharu.koharuclient.client.module;

public enum Category {
    Combat,
    Crystal,
    Movement,
    Exploit,
    Utility,
    Render,
    HUD,
    Misc,
    World,
    Blatant,
    Configs,
    Client,
    Macros,
    Filters,
    CartPvP,
    Mace,
    UHC,
    Farming
}