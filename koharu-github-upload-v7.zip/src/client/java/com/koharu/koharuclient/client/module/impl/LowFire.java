package com.koharu.koharuclient.client.module.impl;

import com.koharu.koharuclient.client.module.Category;
import com.koharu.koharuclient.client.module.Module;

public class LowFire extends Module {
    public LowFire() {
        super("LowFire", Category.Render, "Removes the on-screen fire overlay while burning.");
    }
}

