package com.koharu.koharuclient.client.module.impl;

import com.koharu.koharuclient.client.KoharuClient;
import com.koharu.koharuclient.client.module.Category;
import com.koharu.koharuclient.client.module.Module;
import com.koharu.koharuclient.client.setting.Setting;
import net.minecraft.world.phys.AABB;

public class BridgeAssist extends Module {
    private boolean isShifting = false;
    public BridgeAssist() {
        super("BridgeAssist", Category.Utility, "Uses Meteor's SafeWalk logic to perfectly sneak at edges.");
    }

    @Override
    public void onTick() {
        if (mc == null || mc.player == null || mc.level == null) return;

        Setting modeSet = KoharuClient.INSTANCE.settingsManager.getSettingByName(this, "Mode");
        if (modeSet != null && modeSet.getValString().equals("Blatant")) {
            unShift();
            return;
        }

        Setting pitchCheck = KoharuClient.INSTANCE.settingsManager.getSettingByName(this, "Pitch Check");
        if (pitchCheck != null && pitchCheck.getValBoolean() && mc.player.getXRot() < 45.0f) {
            unShift();
            return;
        }

        Setting edgeSet = KoharuClient.INSTANCE.settingsManager.getSettingByName(this, "Edge Distance");
        double edgeDistance = edgeSet != null ? edgeSet.getValDouble() : 0.25;

        AABB playerBox = mc.player.getBoundingBox();
        
        AABB adjustedBox = playerBox
            .expandTowards(0, -mc.player.maxUpStep(), 0)
            .inflate(-edgeDistance, 0, -edgeDistance);

        boolean closeToEdge = mc.level.noCollision(mc.player, adjustedBox) && mc.player.onGround();

        if (closeToEdge) {
            mc.options.keyShift.setDown(true);
            isShifting = true;
        } else {
            unShift();
        }
    }

    private void unShift() {
        if (isShifting) {
            mc.options.keyShift.setDown(false);
            isShifting = false;
        }
    }

    @Override
    public void onDisable() {
        unShift();
    }
}