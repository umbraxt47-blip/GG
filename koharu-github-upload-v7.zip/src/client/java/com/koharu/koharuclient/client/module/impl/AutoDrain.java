package com.koharu.koharuclient.client.module.impl;

import com.koharu.koharuclient.client.KoharuClient;
import com.koharu.koharuclient.client.module.Category;
import com.koharu.koharuclient.client.module.Module;
import com.koharu.koharuclient.client.setting.Setting;
import com.koharu.koharuclient.client.utils.ModuleUtils;
import com.koharu.koharuclient.client.utils.RotationManager;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.phys.Vec3;

public class AutoDrain extends Module {
    private long lastActionTime = 0;
    private boolean isSwappingBack = false;
    private int originalSlot = -1;
    private long swapBackTime = 0;
    private BlockPos currentTarget = null;
    private int useSlotCached = -1;
    private boolean useWebCached = false;

    public AutoDrain() {
        super("AutoDrain", Category.Utility, "Instantly removes enemy water using webs or buckets.");
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.level == null) return;

        Setting delaySetting = KoharuClient.INSTANCE.settingsManager.getSettingByName(this, "Delay (ms)");
        long delay = delaySetting != null ? (long) delaySetting.getValDouble() : 150;
        if (System.currentTimeMillis() - lastActionTime < delay) return;

        Setting moveCorrectSetting = KoharuClient.INSTANCE.settingsManager.getSettingByName(this, "Movement Correction");
        boolean moveCorrect = moveCorrectSetting != null && moveCorrectSetting.getValBoolean();

        Setting smoothSetting = KoharuClient.INSTANCE.settingsManager.getSettingByName(this, "Smooth Rotation");
        float turnSpeed = smoothSetting != null ? (float)(90.0 / Math.max(1, smoothSetting.getValDouble())) : 45f;

        if (currentTarget == null) {
            currentTarget = findWaterTarget();
            if (currentTarget == null) return;

            int webSlot = ModuleUtils.findItemInHotbar(Items.COBWEB);
            int bucketSlot = ModuleUtils.findItemInHotbar(Items.BUCKET);
            if (webSlot == -1 && bucketSlot == -1) { currentTarget = null; return; }
            useWebCached = webSlot != -1;
            useSlotCached = useWebCached ? webSlot : bucketSlot;
            originalSlot = mc.player.getInventory().getSelectedSlot();
        }

        Vec3 eyes = mc.player.getEyePosition();
        Vec3 waterCenter = new Vec3(currentTarget.getX() + 0.5, currentTarget.getY() + 0.5, currentTarget.getZ() + 0.5);
        if (!RotationManager.hasLineOfSight(eyes, waterCenter)) { currentTarget = null; return; }

        float[] rots = ModuleUtils.getRotations(eyes, waterCenter);
        RotationManager.keepRotated(rots[0], rots[1], turnSpeed, moveCorrect);

        float yawDiff = Math.abs(net.minecraft.util.Mth.wrapDegrees(rots[0] - RotationManager.getServerYaw()));
        float pitchDiff = Math.abs(rots[1] - RotationManager.getServerPitch());
        if (yawDiff > 5f || pitchDiff > 5f) return;

        ModuleUtils.spoofSlot(useSlotCached);
        if (useWebCached) {
            Direction dir = Direction.getNearest(
                (int)(eyes.x - currentTarget.getX()),
                (int)(eyes.y - currentTarget.getY()),
                (int)(eyes.z - currentTarget.getZ()),
                Direction.UP
            );
            ModuleUtils.spoofPlaceBlockPacket(currentTarget, dir.getOpposite());
        } else {
            ModuleUtils.useItemPacket();
        }

        ModuleUtils.spoofRestore();
        lastActionTime = System.currentTimeMillis();
        currentTarget = null;
        isSwappingBack = false;
    }

    private BlockPos findWaterTarget() {
        int radius = 6;
        BlockPos playerPos = mc.player.blockPosition();

        Player closestEnemy = null;
        double closestDist = Double.MAX_VALUE;
        for (Entity entity : mc.level.entitiesForRendering()) {
            if (entity instanceof Player p && p != mc.player && p.isAlive() && mc.player.distanceTo(p) <= 8.0) {
                double d = mc.player.distanceTo(p);
                if (d < closestDist) { closestDist = d; closestEnemy = p; }
            }
        }

        BlockPos searchCenter = closestEnemy != null ? closestEnemy.blockPosition() : playerPos;
        int searchRadius = closestEnemy != null ? 3 : radius;

        for (int x = -searchRadius; x <= searchRadius; x++) {
            for (int y = -searchRadius; y <= searchRadius; y++) {
                for (int z = -searchRadius; z <= searchRadius; z++) {
                    BlockPos pos = searchCenter.offset(x, y, z);
                    if (pos.getY() >= playerPos.getY() && pos.getY() <= playerPos.getY() + 1) {
                        double distToPlayerFeet = Math.sqrt(
                            (pos.getX() - playerPos.getX()) * (pos.getX() - playerPos.getX()) +
                            (pos.getZ() - playerPos.getZ()) * (pos.getZ() - playerPos.getZ())
                        );
                        if (distToPlayerFeet < 1.5) continue;
                    }
                    if (mc.level.getFluidState(pos).getType() == Fluids.WATER && mc.level.getFluidState(pos).isSource()) {
                        Vec3 eyes = mc.player.getEyePosition();
                        if (RotationManager.hasLineOfSight(eyes, new Vec3(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5))) return pos;
                    }
                }
            }
        }
        return null;
    }

    @Override
    public void onDisable() {
        if (isSwappingBack && originalSlot != -1 && mc.player != null) {
            ModuleUtils.switchToSlot(originalSlot);
        }
        isSwappingBack = false;
        currentTarget = null;
        RotationManager.requestReturn();
    }
}