package com.koharu.koharuclient.client.render;

import com.koharu.koharuclient.client.KoharuClient;
import com.koharu.koharuclient.client.module.impl.*;
import xyz.breadloaf.imguimc.interfaces.Renderable;
import xyz.breadloaf.imguimc.interfaces.Theme;
import xyz.breadloaf.imguimc.theme.ImGuiDarkTheme;

public class ImGuiOverlayRenderable implements Renderable {
    private static final Theme THEME = new ImGuiDarkTheme();

    @Override
    public String getName() {
        return "ImGui Overlay Engine";
    }

    @Override
    public Theme getTheme() {
        return THEME;
    }

    @Override
    public void render() {
        if (KoharuClient.INSTANCE == null || KoharuClient.INSTANCE.moduleManager == null) return;

        com.koharu.koharuclient.client.clickgui.ImGuiClickGui.render();

        ESP esp = (ESP) KoharuClient.INSTANCE.moduleManager.getModule("ESP");
        if (esp != null && esp.isToggled()) {
            esp.renderImGuiOverlay();
        }

        Nametags nametags = (Nametags) KoharuClient.INSTANCE.moduleManager.getModule("Nametags");
        if (nametags != null && nametags.isToggled()) {
            nametags.renderImGuiOverlay();
        }

        StorageESP storageESP = (StorageESP) KoharuClient.INSTANCE.moduleManager.getModule("StorageESP");
        if (storageESP != null && storageESP.isToggled()) {
            storageESP.renderImGuiOverlay();
        }

        Tracers tracers = (Tracers) KoharuClient.INSTANCE.moduleManager.getModule("Tracers");
        if (tracers != null && tracers.isToggled()) {
            tracers.renderImGuiOverlay();
        }

        Trajectories trajectories = (Trajectories) KoharuClient.INSTANCE.moduleManager.getModule("Trajectories");
        if (trajectories != null && trajectories.isToggled()) {
            trajectories.renderImGuiOverlay();
        }

        com.koharu.koharuclient.client.ui.ArrayListHud.INSTANCE.renderImGui();

        TargetHUD targetHUD = (TargetHUD) KoharuClient.INSTANCE.moduleManager.getModule("TargetHUD");
        if (targetHUD != null) {
            targetHUD.renderImGuiOverlay();
        }

        BlockESP blockESP = (BlockESP) KoharuClient.INSTANCE.moduleManager.getModule("BlockESP");
        if (blockESP != null) {
            blockESP.renderImGuiOverlay();
            blockESP.renderImGuiSelectorWindow();
        }

        SpawnerFinder spawnerFinder = (SpawnerFinder) KoharuClient.INSTANCE.moduleManager.getModule("SpawnerFinder");
        if (spawnerFinder != null) {
            spawnerFinder.renderImGuiOverlay();
        }

        SuspiciousChunks suspiciousChunks = (SuspiciousChunks) KoharuClient.INSTANCE.moduleManager.getModule("SuspiciousChunks");
        if (suspiciousChunks != null) {
            suspiciousChunks.renderImGuiOverlay();
        }

        WeakDevice weakDevice = (WeakDevice) KoharuClient.INSTANCE.moduleManager.getModule("WeakDevice");
        if (weakDevice != null) {
            weakDevice.renderImGuiOverlay();
        }
    }
}
