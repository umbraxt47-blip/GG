package com.koharu.koharuclient.client.clickgui;

import com.koharu.koharuclient.client.KoharuClient;
import com.koharu.koharuclient.client.module.Category;
import com.koharu.koharuclient.client.module.Module;
import com.koharu.koharuclient.client.module.impl.GUI;
import com.koharu.koharuclient.client.setting.ConfigManager;
import com.koharu.koharuclient.client.setting.Setting;
import com.koharu.koharuclient.client.utils.FontUtils;
import com.koharu.koharuclient.client.utils.InputUtil;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Square "box" style click GUI built only on vanilla GuiGraphics (no ImGui, no natives).
 *
 * Layout: [ categories | modules | settings of selected module ]
 *  - left click a module: toggle it
 *  - right click a module: open its settings
 *  - click the bind button in the settings column, then press a key (Backspace = clear, Esc = cancel)
 */
public class BoxGui extends Screen {

    // ---- palette (change these to restyle everything) ----
    private static final int C_BG        = 0xF00D0F14;
    private static final int C_BOX       = 0xFF151821;
    private static final int C_BOX_HOVER = 0xFF1D212D;
    private static final int C_BORDER    = 0xFF2A2F3E;
    private static final int C_ACCENT    = 0xFF4DA3FF;
    private static final int C_ACCENT_DK = 0xFF1F4E80;
    private static final int C_TEXT      = 0xFFE6E8EE;
    private static final int C_TEXT_DIM  = 0xFF8A90A0;
    private static final int C_ON        = 0xFF3DDC84;
    private static final int C_OFF       = 0xFF3A3F50;

    private static final int PAD = 6;
    private static final int ROW_H = 20;
    private static final int GAP = 4;

    private static BoxGui lastInstance;

    private final List<Category> categories = new ArrayList<>();
    private Category selectedCategory;
    private Module selectedModule;

    private int moduleScroll = 0;
    private int settingScroll = 0;

    private Setting draggingSlider = null;
    private int draggingSliderX, draggingSliderW;
    private Module bindingModule = null;

    // window geometry (recomputed every frame)
    private int wx, wy, ww, wh;
    private int catW, modW;

    public BoxGui() {
        super(Component.literal("Menu"));
        KoharuClient client = KoharuClient.INSTANCE;
        if (client != null && client.moduleManager != null) {
            for (Category c : Category.values()) {
                boolean any = false;
                for (Module m : client.moduleManager.getModules(c)) {
                    if (!m.isHidden()) { any = true; break; }
                }
                if (any) categories.add(c);
            }
        }
        if (lastInstance != null && categories.contains(lastInstance.selectedCategory)) {
            selectedCategory = lastInstance.selectedCategory;
        } else if (!categories.isEmpty()) {
            selectedCategory = categories.get(0);
        }
        lastInstance = this;
    }

    // ------------------------------------------------------------------ helpers

    private List<Module> modulesOf(Category c) {
        List<Module> out = new ArrayList<>();
        KoharuClient client = KoharuClient.INSTANCE;
        if (client == null || client.moduleManager == null || c == null) return out;
        for (Module m : client.moduleManager.getModules(c)) {
            if (!m.isHidden()) out.add(m);
        }
        return out;
    }

    private static boolean inside(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private static void box(GuiGraphics g, int x, int y, int w, int h, int fill, int border) {
        g.fill(x, y, x + w, y + h, border);
        g.fill(x + 1, y + 1, x + w - 1, y + h - 1, fill);
    }

    private static void text(GuiGraphics g, String s, int x, int y, int color) {
        FontUtils.drawString(g, s, x, y, color, false);
    }

    private static String clip(String s, int maxW) {
        if (s == null) return "";
        if (FontUtils.width(s) <= maxW) return s;
        while (s.length() > 1 && FontUtils.width(s + "..") > maxW) {
            s = s.substring(0, s.length() - 1);
        }
        return s + "..";
    }

    private void layout() {
        ww = Math.min(this.width - 20, 560);
        wh = Math.min(this.height - 20, 320);
        wx = (this.width - ww) / 2;
        wy = (this.height - wh) / 2;
        catW = Math.max(80, ww / 5);
        modW = Math.max(120, (ww - catW) * 2 / 5);
    }

    private int contentTop() { return wy + 22; }
    private int contentH() { return wh - 22 - PAD; }

    // ------------------------------------------------------------------ render

    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float delta) {
        // no blur, just a dim overlay (drawn in render)
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        layout();
        g.fill(0, 0, this.width, this.height, 0x66000000);

        // window
        box(g, wx, wy, ww, wh, C_BG, C_BORDER);

        // title bar
        g.fill(wx + 1, wy + 1, wx + ww - 1, wy + 20, C_BOX);
        g.fill(wx + 1, wy + 20, wx + ww - 1, wy + 21, C_ACCENT);
        text(g, "MENU", wx + PAD + 2, wy + 7, C_ACCENT);
        if (selectedCategory != null) {
            String sub = selectedCategory.name() + (selectedModule != null ? "  /  " + selectedModule.getName() : "");
            FontUtils.drawRightAlignedString(g, clip(sub, ww / 2), wx + ww - PAD - 2, wy + 7, C_TEXT_DIM);
        }

        renderCategories(g, mouseX, mouseY);
        renderModules(g, mouseX, mouseY);
        renderSettings(g, mouseX, mouseY);

        // tooltip
        Module hov = hoveredModule(mouseX, mouseY);
        if (hov != null && hov.getDescription() != null && !hov.getDescription().isEmpty()) {
            String d = clip(hov.getDescription(), 260);
            int tw = FontUtils.width(d) + 8;
            int tx = Math.min(mouseX + 8, this.width - tw - 2);
            int ty = Math.max(2, mouseY - 18);
            box(g, tx, ty, tw, 14, C_BOX, C_ACCENT);
            text(g, d, tx + 4, ty + 3, C_TEXT);
        }
    }

    private void renderCategories(GuiGraphics g, int mx, int my) {
        int x = wx + PAD;
        int y = contentTop() + PAD;
        int w = catW - PAD;
        for (Category c : categories) {
            boolean sel = c == selectedCategory;
            boolean hov = inside(mx, my, x, y, w, ROW_H);
            box(g, x, y, w, ROW_H, sel ? C_ACCENT_DK : (hov ? C_BOX_HOVER : C_BOX), sel ? C_ACCENT : C_BORDER);
            text(g, clip(c.name(), w - 12), x + 6, y + 6, sel ? C_TEXT : C_TEXT_DIM);
            y += ROW_H + GAP;
        }
    }

    private void renderModules(GuiGraphics g, int mx, int my) {
        int x = wx + catW + PAD;
        int y0 = contentTop() + PAD;
        int w = modW - PAD;
        int h = contentH() - PAD;
        List<Module> mods = modulesOf(selectedCategory);

        int total = mods.size() * (ROW_H + GAP);
        moduleScroll = Math.max(0, Math.min(moduleScroll, Math.max(0, total - h)));

        g.enableScissor(x, y0, x + w, y0 + h);
        int y = y0 - moduleScroll;
        for (Module m : mods) {
            if (y + ROW_H >= y0 && y <= y0 + h) {
                boolean sel = m == selectedModule;
                boolean hov = inside(mx, my, x, y, w, ROW_H) && inside(mx, my, x, y0, w, h);
                box(g, x, y, w, ROW_H, hov ? C_BOX_HOVER : C_BOX, sel ? C_ACCENT : C_BORDER);
                // state square
                int sq = 8;
                g.fill(x + 6, y + 6, x + 6 + sq, y + 6 + sq, m.isToggled() ? C_ON : C_OFF);
                text(g, clip(m.getName(), w - 30), x + 20, y + 6, m.isToggled() ? C_TEXT : C_TEXT_DIM);
            }
            y += ROW_H + GAP;
        }
        g.disableScissor();
    }

    private Module hoveredModule(int mx, int my) {
        int x = wx + catW + PAD;
        int y0 = contentTop() + PAD;
        int w = modW - PAD;
        int h = contentH() - PAD;
        if (!inside(mx, my, x, y0, w, h)) return null;
        List<Module> mods = modulesOf(selectedCategory);
        int idx = (my - y0 + moduleScroll) / (ROW_H + GAP);
        int within = (my - y0 + moduleScroll) % (ROW_H + GAP);
        if (idx >= 0 && idx < mods.size() && within < ROW_H) return mods.get(idx);
        return null;
    }

    private int settingsX() { return wx + catW + modW + PAD; }
    private int settingsW() { return ww - catW - modW - PAD * 2; }

    private void renderSettings(GuiGraphics g, int mx, int my) {
        int x = settingsX();
        int y0 = contentTop() + PAD;
        int w = settingsW();
        int h = contentH() - PAD;
        box(g, x, y0, w, h, C_BOX, C_BORDER);

        if (selectedModule == null) {
            text(g, "Right click a module", x + 8, y0 + 8, C_TEXT_DIM);
            text(g, "to see its settings", x + 8, y0 + 20, C_TEXT_DIM);
            return;
        }

        List<Setting> settings = visibleSettings(selectedModule);
        int total = 28 + (ROW_H + GAP) * (settings.size() + 1);
        settingScroll = Math.max(0, Math.min(settingScroll, Math.max(0, total - h)));

        g.enableScissor(x + 1, y0 + 1, x + w - 1, y0 + h - 1);
        int y = y0 + 6 - settingScroll;
        int ix = x + 6;
        int iw = w - 12;

        text(g, clip(selectedModule.getName(), iw), ix, y, C_ACCENT);
        y += 14;
        g.fill(ix, y, ix + iw, y + 1, C_BORDER);
        y += 8;

        // bind row
        {
            boolean listening = bindingModule == selectedModule;
            boolean hov = inside(mx, my, ix, y, iw, ROW_H);
            box(g, ix, y, iw, ROW_H, hov ? C_BOX_HOVER : C_BG, listening ? C_ACCENT : C_BORDER);
            text(g, "Bind", ix + 6, y + 6, C_TEXT_DIM);
            String bn = listening ? "..." : InputUtil.getName(selectedModule.getKeyBind());
            FontUtils.drawRightAlignedString(g, clip(bn, iw / 2), ix + iw - 6, y + 6, C_TEXT);
            y += ROW_H + GAP;
        }

        for (Setting s : settings) {
            drawSetting(g, s, ix, y, iw, mx, my);
            y += ROW_H + GAP;
        }
        g.disableScissor();
    }

    private List<Setting> visibleSettings(Module m) {
        List<Setting> out = new ArrayList<>();
        try {
            for (Setting s : m.getSettings()) {
                if (s.isVisible()) out.add(s);
            }
        } catch (Exception ignored) {}
        return out;
    }

    private void drawSetting(GuiGraphics g, Setting s, int x, int y, int w, int mx, int my) {
        boolean hov = inside(mx, my, x, y, w, ROW_H);
        box(g, x, y, w, ROW_H, hov ? C_BOX_HOVER : C_BG, C_BORDER);

        if (s.isCheck()) {
            text(g, clip(s.getName(), w - 30), x + 6, y + 6, C_TEXT);
            int sx = x + w - 6 - 10;
            g.fill(sx, y + 5, sx + 10, y + 15, C_BORDER);
            g.fill(sx + 1, y + 6, sx + 9, y + 14, s.getValBoolean() ? C_ON : C_OFF);
        } else if (s.isSlider()) {
            double range = s.getMax() - s.getMin();
            double frac = range <= 0 ? 0 : (s.getValDouble() - s.getMin()) / range;
            frac = Math.max(0, Math.min(1, frac));
            g.fill(x + 1, y + 1, x + 1 + (int) ((w - 2) * frac), y + ROW_H - 1, C_ACCENT_DK);
            g.fill(x + 1 + (int) ((w - 2) * frac) - 1, y + 1, x + 1 + (int) ((w - 2) * frac), y + ROW_H - 1, C_ACCENT);
            text(g, clip(s.getName(), w / 2), x + 6, y + 6, C_TEXT);
            String v = s.onlyInt() ? String.valueOf((int) s.getValDouble()) : String.format("%.2f", s.getValDouble());
            FontUtils.drawRightAlignedString(g, v, x + w - 6, y + 6, C_TEXT);
        } else if (s.isCombo()) {
            text(g, clip(s.getName(), w / 2 - 4), x + 6, y + 6, C_TEXT_DIM);
            FontUtils.drawRightAlignedString(g, clip(s.getValString(), w / 2 - 8), x + w - 6, y + 6, C_ACCENT);
        } else if (s.isColor()) {
            text(g, clip(s.getName(), w - 30), x + 6, y + 6, C_TEXT);
            int sx = x + w - 6 - 12;
            g.fill(sx - 1, y + 4, sx + 13, y + 16, C_BORDER);
            g.fill(sx, y + 5, sx + 12, y + 15, s.getValColor() | 0xFF000000);
        } else {
            // text / range / curve etc.: shown read-only
            text(g, clip(s.getName(), w - 12), x + 6, y + 6, C_TEXT_DIM);
        }
    }

    // ------------------------------------------------------------------ input

    @Override
    public boolean mouseClicked(MouseButtonEvent click, boolean doubled) {
        layout();
        double mx = click.x(), my = click.y();
        int button = click.button();

        // categories
        {
            int x = wx + PAD, y = contentTop() + PAD, w = catW - PAD;
            for (Category c : categories) {
                if (inside(mx, my, x, y, w, ROW_H)) {
                    selectedCategory = c;
                    selectedModule = null;
                    moduleScroll = 0;
                    settingScroll = 0;
                    return true;
                }
                y += ROW_H + GAP;
            }
        }

        // modules
        {
            int x = wx + catW + PAD, y0 = contentTop() + PAD, w = modW - PAD, h = contentH() - PAD;
            if (inside(mx, my, x, y0, w, h)) {
                Module m = hoveredModule((int) mx, (int) my);
                if (m != null) {
                    if (button == 0) {
                        m.toggle();
                        save();
                    } else if (button == 1) {
                        selectedModule = m;
                        settingScroll = 0;
                        bindingModule = null;
                    }
                }
                return true;
            }
        }

        // settings
        if (selectedModule != null) {
            int x = settingsX(), y0 = contentTop() + PAD, w = settingsW(), h = contentH() - PAD;
            if (inside(mx, my, x, y0, w, h)) {
                int ix = x + 6, iw = w - 12;
                int y = y0 + 6 - settingScroll + 14 + 8;

                // bind row
                if (inside(mx, my, ix, y, iw, ROW_H)) {
                    if (button == 0) bindingModule = selectedModule;
                    return true;
                }
                y += ROW_H + GAP;

                for (Setting s : visibleSettings(selectedModule)) {
                    if (inside(mx, my, ix, y, iw, ROW_H)) {
                        clickSetting(s, ix, iw, mx, button);
                        return true;
                    }
                    y += ROW_H + GAP;
                }
                return true;
            }
        }

        return super.mouseClicked(click, doubled);
    }

    private void clickSetting(Setting s, int x, int w, double mx, int button) {
        if (s.isCheck()) {
            if (button == 0) {
                s.setValBoolean(!s.getValBoolean());
                save();
            }
        } else if (s.isSlider()) {
            if (button == 0) {
                draggingSlider = s;
                draggingSliderX = x;
                draggingSliderW = w;
                applySlider(mx);
            }
        } else if (s.isCombo()) {
            ArrayList<String> opts = s.getOptions();
            if (opts != null && !opts.isEmpty()) {
                int idx = opts.indexOf(s.getValString());
                if (button == 0) idx = (idx + 1) % opts.size();
                else if (button == 1) idx = (idx - 1 + opts.size()) % opts.size();
                s.setValString(opts.get(idx));
                save();
            }
        }
    }

    private void applySlider(double mx) {
        if (draggingSlider == null || draggingSliderW <= 0) return;
        double frac = (mx - draggingSliderX) / (double) draggingSliderW;
        frac = Math.max(0, Math.min(1, frac));
        double v = draggingSlider.getMin() + frac * (draggingSlider.getMax() - draggingSlider.getMin());
        if (draggingSlider.onlyInt()) v = Math.round(v);
        else v = Math.round(v * 100.0) / 100.0;
        draggingSlider.setValDouble(v);
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dragX, double dragY) {
        if (draggingSlider != null) {
            applySlider(event.x());
            return true;
        }
        return super.mouseDragged(event, dragX, dragY);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        if (draggingSlider != null) {
            draggingSlider = null;
            save();
            return true;
        }
        return super.mouseReleased(event);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double horizontal, double vertical) {
        layout();
        int step = (int) (-vertical * 14);
        if (mx >= wx + catW && mx < wx + catW + modW) {
            moduleScroll += step;
            return true;
        }
        if (mx >= settingsX()) {
            settingScroll += step;
            return true;
        }
        return super.mouseScrolled(mx, my, horizontal, vertical);
    }

    @Override
    public boolean keyPressed(KeyEvent input) {
        int key = input.input();

        if (bindingModule != null) {
            if (key == InputConstants.KEY_ESCAPE) {
                // cancel
            } else if (key == InputConstants.KEY_BACKSPACE || key == InputConstants.KEY_DELETE) {
                bindingModule.setKeyBind(0);
            } else {
                bindingModule.setKeyBind(key);
            }
            bindingModule = null;
            save();
            return true;
        }

        KoharuClient client = KoharuClient.INSTANCE;
        Module guiMod = client != null && client.moduleManager != null ? client.moduleManager.getModule("GUI") : null;
        int guiKey = guiMod != null && guiMod.getKeyBind() != 0 ? guiMod.getKeyBind() : InputConstants.KEY_RSHIFT;
        if (key == guiKey || key == InputConstants.KEY_ESCAPE) {
            this.onClose();
            return true;
        }
        return super.keyPressed(input);
    }

    @Override
    public void onClose() {
        save();
        GUI.notifyGuiClosed();
        super.onClose();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    private void save() {
        try { ConfigManager.save(); } catch (Exception ignored) {}
    }
}
