package com.koharu.koharuclient.client.module.impl;

import com.koharu.koharuclient.client.KoharuClient;
import com.koharu.koharuclient.client.module.Category;
import com.koharu.koharuclient.client.module.Module;
import com.koharu.koharuclient.client.setting.Setting;

public class FastBreak extends Module {
    public FastBreak() {
        super("FastBreak", Category.World);
        KoharuClient.INSTANCE.settingsManager.rSetting(new Setting("Speed Multiplier", this, 1.07, 1.05, 1.10, false));
    }
}
