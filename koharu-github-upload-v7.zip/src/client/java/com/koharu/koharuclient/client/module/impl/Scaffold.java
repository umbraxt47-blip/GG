package com.koharu.koharuclient.client.module.impl;

import com.koharu.koharuclient.client.KoharuClient;
import com.koharu.koharuclient.client.module.Category;
import com.koharu.koharuclient.client.module.Module;

public class Scaffold extends Module {

    public Scaffold() {
        super("Scaffold", Category.World, "Macro: Holds S, enables BridgeAssist & FastPlace.");
    }

    @Override
    public void onEnable() {
        Module bridgeAssist = KoharuClient.INSTANCE.moduleManager.getModule("BridgeAssist");
        Module fastPlace = KoharuClient.INSTANCE.moduleManager.getModule("FastPlace");
        
        if (bridgeAssist != null && !bridgeAssist.isToggled()) bridgeAssist.toggle();
        if (fastPlace != null && !fastPlace.isToggled()) fastPlace.toggle();
    }

    @Override
    public void onTick() {
        if (mc != null && mc.player != null && mc.screen == null) {
            mc.options.keyDown.setDown(true);
            mc.options.keyUse.setDown(true);
        }
    }

    @Override
    public void onDisable() {
        Module bridgeAssist = KoharuClient.INSTANCE.moduleManager.getModule("BridgeAssist");
        Module fastPlace = KoharuClient.INSTANCE.moduleManager.getModule("FastPlace");
        
        if (bridgeAssist != null && bridgeAssist.isToggled()) bridgeAssist.toggle();
        if (fastPlace != null && fastPlace.isToggled()) fastPlace.toggle();

        if (mc.options != null) {
            mc.options.keyDown.setDown(false);
            mc.options.keyUse.setDown(false);
        }
    }
}