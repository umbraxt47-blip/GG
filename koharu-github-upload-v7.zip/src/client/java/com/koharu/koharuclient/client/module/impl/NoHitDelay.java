package com.koharu.koharuclient.client.module.impl;

import com.koharu.koharuclient.client.module.Category;
import com.koharu.koharuclient.client.module.Module;
import com.koharu.koharuclient.mixin.client.MinecraftAccessor;
import net.minecraft.world.entity.Entity;

public class NoHitDelay extends Module {

    public NoHitDelay() {
        super("NoHitDelay", Category.Combat);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.level == null) return;
        
        if (mc instanceof MinecraftAccessor accessor) {
            accessor.setMissTime(0);
        }

        for (Entity entity : mc.level.entitiesForRendering()) {
            entity.invulnerableTime = 0;
        }
    }
}
