package com.koharu.koharuclient.client.module.impl;

import com.koharu.koharuclient.client.module.Category;
import com.koharu.koharuclient.client.module.Module;

public class ArrayListMod extends Module {
    public ArrayListMod() {
        super("ArrayList", Category.HUD);
        this.toggle();
    }
}