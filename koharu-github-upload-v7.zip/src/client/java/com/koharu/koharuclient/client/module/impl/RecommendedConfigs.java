package com.koharu.koharuclient.client.module.impl;

import com.koharu.koharuclient.client.KoharuClient;
import com.koharu.koharuclient.client.clickgui.ConfigRecommendationScreen;
import com.koharu.koharuclient.client.module.Category;
import com.koharu.koharuclient.client.module.Module;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.network.chat.Component;

import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.CompletableFuture;

public class RecommendedConfigs extends Module {
    private String lastServerIp = null;
    private boolean fetched = false;

    public static class FoundConfig {
        public String name;
        public String base64;
        public String modulesPreview;

        public FoundConfig(String name, String base64, String modulesPreview) {
            this.name = name;
            this.base64 = base64;
            this.modulesPreview = modulesPreview;
        }
    }

    private List<FoundConfig> currentServerConfigs = new ArrayList<>();

    public RecommendedConfigs() {
        super("RecommendedConfigs", Category.Misc, "Recommends server-specific configs upon joining.", true);
        this.setToggled(true);
    }

    @Override
    public void onTick() {
        if (!isToggled() || mc.player == null) return;

        String currentServer = mc.getCurrentServer() != null ? mc.getCurrentServer().ip : null;

        if (currentServer != null && !currentServer.equals(lastServerIp)) {
            lastServerIp = currentServer;
            fetched = false;
            currentServerConfigs.clear();
            fetchConfigsAndCheck(currentServer);
        } else if (currentServer == null) {
            lastServerIp = null;
            fetched = false;
            currentServerConfigs.clear();
        }

        if (fetched && currentServer != null && mc.screen == null && !currentServerConfigs.isEmpty()) {
            mc.setScreenAndShow(new ConfigRecommendationScreen(new ArrayList<>(currentServerConfigs)));
            currentServerConfigs.clear(); 
        }
    }

    private void fetchConfigsAndCheck(String ip) {
    }
}
