package com.koharu.koharuclient.client.module.impl;

import com.koharu.koharuclient.client.module.Category;
import com.koharu.koharuclient.client.module.Module;

public class HUDEditor extends Module {
    public HUDEditor() {
        super("HUDEditor", Category.HUD, "Opens the interactive screen overlay editor.");
        this.setKeyBind(com.mojang.blaze3d.platform.InputConstants.KEY_GRAVE);
    }

    @Override
    public void onEnable() {
        if (mc.player == null) {
            setToggled(false);
            return;
        }
        mc.setScreenAndShow(new com.koharu.koharuclient.client.clickgui.HudEditorScreen());
        setToggled(false);
    }
}
