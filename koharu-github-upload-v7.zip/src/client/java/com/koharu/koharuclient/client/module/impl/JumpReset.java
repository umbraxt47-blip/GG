package com.koharu.koharuclient.client.module.impl;

import com.koharu.koharuclient.client.KoharuClient;
import com.koharu.koharuclient.client.module.Category;
import com.koharu.koharuclient.client.module.Module;
import com.koharu.koharuclient.client.setting.Setting;

public class JumpReset extends Module {
    private int hitsInTrade = 0;
    private long lastHitTime = 0;
    private boolean shouldJump = false;
    private int jumpDelayTicks = 0;
    private boolean keyWasPressed = false;

    private long lastKnockbackTime = 0;

    public JumpReset() {
        super("JumpReset", Category.Utility, "Converts horizontal KB into vertical KB by jumping on specific hits.");
    }

    @Override
    public void onTick() {
        if (!isToggled() || mc.player == null || mc.options == null) return;

        if (keyWasPressed) {
            if (!isPhysicallyHoldingJump()) {
                mc.options.keyJump.setDown(false);
            }
            keyWasPressed = false;
        }

        Setting timeoutSetting = KoharuClient.INSTANCE.settingsManager.getSettingByName(this, "Trade Timeout (ms)");
        long timeout = timeoutSetting != null ? (long) timeoutSetting.getValDouble() : 500;
        if (System.currentTimeMillis() - lastHitTime > timeout) {
            hitsInTrade = 0;
        }

        if (shouldJump) {
            if (System.currentTimeMillis() - lastKnockbackTime > 250) {
                shouldJump = false;
                jumpDelayTicks = 0;
            } else if (mc.player.onGround()) {
                Setting delaySetting = KoharuClient.INSTANCE.settingsManager.getSettingByName(this, "Delay (Ticks)");
                Setting modeSetting = KoharuClient.INSTANCE.settingsManager.getSettingByName(this, "Mode");
                String mode = modeSetting != null ? modeSetting.getValString() : "Smart";
                int delay = (mode.equals("Classic") || mode.equals("Blatant")) ? 0 : (delaySetting != null ? (int) delaySetting.getValDouble() : 0);

                if (jumpDelayTicks >= delay) {
                    mc.options.keyJump.setDown(true);
                    keyWasPressed = true;
                    shouldJump = false;
                    jumpDelayTicks = 0;
                } else {
                    jumpDelayTicks++;
                }
            }
        }
    }

    public static long lastExplosionTime = 0L;

    public void onKnockback() {
        if (!isToggled() || mc.player == null) return;
        if (mc.player.isBlocking()) return;
        if (System.currentTimeMillis() - lastExplosionTime < 1000L) return;
        
        if (System.currentTimeMillis() - lastHitTime < 50) return;

        lastHitTime = System.currentTimeMillis();
        lastKnockbackTime = lastHitTime;
        hitsInTrade++;

        Setting chanceSetting = KoharuClient.INSTANCE.settingsManager.getSettingByName(this, "Chance (%)");
        double chance = chanceSetting != null ? chanceSetting.getValDouble() : 100.0;
        if (Math.random() * 100.0 > chance) return;

        Setting modeSetting = KoharuClient.INSTANCE.settingsManager.getSettingByName(this, "Mode");
        String mode = modeSetting != null ? modeSetting.getValString() : "Smart";

        if (mode.equals("Classic")) {
            shouldJump = true;
            jumpDelayTicks = 0;
        } else if (mode.equals("Smart")) {
            Setting resetHitSetting = KoharuClient.INSTANCE.settingsManager.getSettingByName(this, "Reset Hit");
            int resetHit = resetHitSetting != null ? (int) resetHitSetting.getValDouble() : 2;

            Setting maxTradeSetting = KoharuClient.INSTANCE.settingsManager.getSettingByName(this, "Max Trade Length");
            int maxTrade = maxTradeSetting != null ? (int) maxTradeSetting.getValDouble() : 4;

            if (hitsInTrade > maxTrade) {
                shouldJump = false;
                return;
            }

            Setting shortTradeSetting = KoharuClient.INSTANCE.settingsManager.getSettingByName(this, "Short Trade Reset");
            boolean shortTrade = shortTradeSetting != null && shortTradeSetting.getValBoolean();

            if (hitsInTrade == resetHit || (shortTrade && hitsInTrade <= 2)) {
                shouldJump = true;
                jumpDelayTicks = 0;
            }
        } else {
            shouldJump = true;
            jumpDelayTicks = 0;
        }
    }

    private boolean isPhysicallyHoldingJump() {
        return com.koharu.koharuclient.client.utils.InputUtil.isDown(getKeyCode(mc.options.keyJump));
    }

    private int getKeyCode(net.minecraft.client.KeyMapping mapping) {
        return mapping.getDefaultKey().getValue();
    }

    private long getWindowHandle() {
        return mc.getWindow().handle();
    }

    @Override
    public void onDisable() {
        shouldJump = false;
        jumpDelayTicks = 0;
        hitsInTrade = 0;
        keyWasPressed = false;
        if (mc.options != null && mc.options.keyJump != null) {
            mc.options.keyJump.setDown(false);
        }
    }
}