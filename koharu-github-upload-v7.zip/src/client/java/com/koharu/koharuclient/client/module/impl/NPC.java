package com.koharu.koharuclient.client.module.impl;

import com.koharu.koharuclient.client.module.Category;
import com.koharu.koharuclient.client.module.Module;

public class NPC extends Module {
    public NPC() {
        super("NPC", Category.Misc, "Allows combat modules to target non-player entities.");
    }
}
