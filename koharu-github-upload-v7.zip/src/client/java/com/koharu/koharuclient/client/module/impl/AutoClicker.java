package com.koharu.koharuclient.client.module.impl;

import com.koharu.koharuclient.client.KoharuClient;
import com.koharu.koharuclient.client.module.Category;
import com.koharu.koharuclient.client.module.Module;
import com.koharu.koharuclient.client.setting.Setting;
import com.koharu.koharuclient.client.utils.cheat.ClickConsistency;
import net.minecraft.client.KeyMapping;

public class AutoClicker extends Module {

    public AutoClicker() {
        super("AutoClicker", Category.Combat, "Automatically clicks for you with randomized CPS.");
    }

    @Override
    public void onTick() {
        if (mc == null || mc.player == null || mc.screen != null) return;

        Setting requireClick = KoharuClient.INSTANCE.settingsManager.getSettingByName(this, "Require Click");
        Setting buttonSet = KoharuClient.INSTANCE.settingsManager.getSettingByName(this, "Button");
        Setting rightClickerSet = KoharuClient.INSTANCE.settingsManager.getSettingByName(this, "Right Clicker");

        boolean rightClickerEnabled = rightClickerSet != null && rightClickerSet.getValBoolean();
        boolean leftClick = buttonSet == null || buttonSet.getValString().equals("Left");

        Setting minCpsSet = KoharuClient.INSTANCE.settingsManager.getSettingByName(this, "Min CPS");
        Setting maxCpsSet = KoharuClient.INSTANCE.settingsManager.getSettingByName(this, "Max CPS");

        double minCps = minCpsSet != null ? minCpsSet.getValDouble() : 9.0;
        double maxCps = maxCpsSet != null ? maxCpsSet.getValDouble() : 14.0;

        if (minCps > maxCps) {
            double temp = minCps; minCps = maxCps; maxCps = temp;
        }

        if (leftClick) {
            KeyMapping targetKey = mc.options.keyAttack;
            if (requireClick == null || !requireClick.getValBoolean() || targetKey.isDown()) {
                double targetCps = minCps + Math.random() * (maxCps - minCps);
                long baseDelayMs = (long) (1000.0 / Math.max(1.0, targetCps));
                if (ClickConsistency.shouldClick(baseDelayMs, (int) maxCps)) {
                    KeyMapping.click(targetKey.getDefaultKey());
                }
            }
        }

        boolean shouldRightClick = (buttonSet != null && buttonSet.getValString().equals("Right")) || rightClickerEnabled;
        if (shouldRightClick) {
            KeyMapping targetKey = mc.options.keyUse;
            if (requireClick == null || !requireClick.getValBoolean() || targetKey.isDown()) {
                double targetCps = minCps + Math.random() * (maxCps - minCps);
                long baseDelayMs = (long) (1000.0 / Math.max(1.0, targetCps));
                if (ClickConsistency.shouldRightClick(baseDelayMs, (int) maxCps)) {
                    KeyMapping.click(targetKey.getDefaultKey());
                }
            }
        }
    }
}