package com.koharu.koharuclient.client.clickgui;

import com.koharu.koharuclient.client.utils.FontUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.io.File;

public class PSAScreen extends Screen {
    private final Screen parentScreen;
    private final long startTime;
    private Button exitButton;

    public PSAScreen(Screen parentScreen) {
        super(Component.literal("PSA Warning"));
        this.parentScreen = parentScreen;
        this.startTime = System.currentTimeMillis();
    }

    @Override
    protected void init() {
        super.init();

        int btnWidth = 200;
        int btnHeight = 20;
        int btnX = this.width / 2 - btnWidth / 2;
        int btnY = this.height - 40;

        this.exitButton = this.addRenderableWidget(Button.builder(Component.literal("Exit"), btn -> {
            try {
                File dir = new File(this.minecraft.gameDirectory, "config/koharuclient");
                if (!dir.exists()) {
                    dir.mkdirs();
                }
                File psaFile = new File(dir, "psa_accepted");
                psaFile.createNewFile();
                com.koharu.koharuclient.client.utils.PsaState.markAccepted();
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (this.minecraft != null) {
                this.minecraft.setScreenAndShow(this.parentScreen);
            }
        }).bounds(btnX, btnY, btnWidth, btnHeight).build());

        this.exitButton.active = true;
    }

    @Override
    public void tick() {
        super.tick();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void renderBackground(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        super.renderBackground(guiGraphics, mouseX, mouseY, partialTick);
        guiGraphics.fill(0, 0, this.width, this.height, 0x80000000);
    }

    @Override
    public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        super.render(guiGraphics, mouseX, mouseY, partialTick);

        int titleY = 30;
        FontUtils.drawCenteredString(guiGraphics, "\u00a7d\u00a7lKoharu Client", this.width / 2, titleY, -1);

        int textY = titleY + 30;
        int spacing = 12;

        FontUtils.drawCenteredString(guiGraphics, "\u00a7fPrivate build for Minecraft 1.21.11", this.width / 2, textY, -1);
    }
}
