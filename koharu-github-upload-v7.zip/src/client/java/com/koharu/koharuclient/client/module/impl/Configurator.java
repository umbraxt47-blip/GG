package com.koharu.koharuclient.client.module.impl;

import com.koharu.koharuclient.client.clickgui.ConfigGui;
import com.koharu.koharuclient.client.module.Category;
import com.koharu.koharuclient.client.module.Module;

public class Configurator extends Module {
    public Configurator() {
        super("Config Menu", Category.Configs);
    }

    @Override
    public void onEnable() {
        if (mc.level != null && mc.player != null) {
            if (mc.screen != null) mc.screen.onClose();
            mc.setScreenAndShow(new ConfigGui());
        }
        this.setToggled(false); 
    }
}