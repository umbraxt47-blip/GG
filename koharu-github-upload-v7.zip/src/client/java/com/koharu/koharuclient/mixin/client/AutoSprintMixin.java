package com.koharu.koharuclient.mixin.client;

import com.koharu.koharuclient.client.KoharuClient;
import com.koharu.koharuclient.client.module.Module;
import net.minecraft.client.player.LocalPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LocalPlayer.class)
public class AutoSprintMixin {
@Inject(method = "tick", at = @At("HEAD"))
private void onTick(CallbackInfo ci) {
Module sprintMod = KoharuClient.INSTANCE.moduleManager.getModule("AutoSprint");
if (sprintMod == null || !sprintMod.isToggled()) return;

    LocalPlayer player = (LocalPlayer) (Object) this;
    
    if (player.zza > 0 && !player.isShiftKeyDown() && !player.isUsingItem()) {
        if (!com.koharu.koharuclient.client.module.impl.WTap.shouldSilentStopSprint()
                && !com.koharu.koharuclient.client.module.impl.STap.shouldSilentStopSprint()
                && !com.koharu.koharuclient.client.module.impl.AutoTotem.shouldPauseInputs()) {
            player.setSprinting(true);
        }
    }
}

}