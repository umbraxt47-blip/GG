package com.koharu.koharuclient.mixin.client;

import com.koharu.koharuclient.client.KoharuClient;
import com.koharu.koharuclient.client.module.Module;
import com.koharu.koharuclient.client.setting.Setting;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.client.renderer.LightTexture;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LightTexture.class)
public class LightTextureMixin {

    private static boolean koharuclient$gammaFullbright() {
        Module fbMod = KoharuClient.INSTANCE.moduleManager.getModule("Fullbright");
        if (fbMod != null && fbMod.isToggled()) {
            Setting mode = KoharuClient.INSTANCE.settingsManager.getSettingByName(fbMod, "Mode");
            return mode != null && mode.getValString().equals("Gamma");
        }
        return false;
    }

    @Inject(method = "getBrightness(Lnet/minecraft/world/level/dimension/DimensionType;I)F", at = @At("HEAD"), cancellable = true)
    private static void onGetBrightness(net.minecraft.world.level.dimension.DimensionType dimensionType, int lightLevel, CallbackInfoReturnable<Float> cir) {
        if (koharuclient$gammaFullbright()) {
            cir.setReturnValue(15.0F);
        }
    }

    @ModifyExpressionValue(
            method = "updateLightTexture",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/OptionInstance;get()Ljava/lang/Object;", ordinal = 2)
    )
    private Object koharuclient$fullbrightGamma(Object original) {
        return koharuclient$gammaFullbright() ? (Object) Double.valueOf(15.0) : original;
    }
}
