package com.koharu.koharuclient.mixin.client;

import com.koharu.koharuclient.client.KoharuClient;
import com.koharu.koharuclient.client.setting.Setting;
import com.koharu.koharuclient.client.module.Module;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public class EntityMixin {

    @Inject(method = "isInvisibleTo(Lnet/minecraft/world/entity/player/Player;)Z", at = @At("HEAD"), cancellable = true)
    private void onIsInvisibleTo(net.minecraft.world.entity.player.Player player, CallbackInfoReturnable<Boolean> cir) {
        Module trueSight = KoharuClient.INSTANCE.moduleManager.getModule("TrueSight");
        if (trueSight != null && trueSight.isToggled()) {
            cir.setReturnValue(false);
        }
    }

    @Inject(method = "isSprinting", at = @At("HEAD"), cancellable = true)
    private void onIsSprinting(CallbackInfoReturnable<Boolean> cir) {
        if ((Object) this instanceof net.minecraft.client.player.LocalPlayer) {
            if (com.koharu.koharuclient.client.module.impl.WTap.shouldSilentStopSprint()
                    || com.koharu.koharuclient.client.module.impl.STap.shouldSilentStopSprint()
                    || com.koharu.koharuclient.client.module.impl.AutoTotem.shouldPauseInputs()) {
                cir.setReturnValue(false);
            }
        }
    }

    @ModifyVariable(method = "move", at = @At("HEAD"), argsOnly = true)
    private net.minecraft.world.phys.Vec3 modifyMove(net.minecraft.world.phys.Vec3 vec) {
        if ((Object) this instanceof net.minecraft.client.player.LocalPlayer player) {
            Module bridgeAssist = KoharuClient.INSTANCE.moduleManager.getModule("BridgeAssist");
            if (bridgeAssist != null && bridgeAssist.isToggled()) {
                Setting modeSet = KoharuClient.INSTANCE.settingsManager.getSettingByName(bridgeAssist, "Mode");
                if (modeSet != null && modeSet.getValString().equals("Blatant")) {
                    if (player.onGround()) {
                        double d = vec.x;
                        double e = vec.z;
                        while (d != 0.0 && player.level().noCollision(player, player.getBoundingBox().move(d, (double)(-player.maxUpStep()), 0.0))) {
                            if (d < 0.05 && d >= -0.05) {
                                d = 0.0;
                            } else if (d > 0.0) {
                                d -= 0.05;
                            } else {
                                d += 0.05;
                            }
                        }

                        while (e != 0.0 && player.level().noCollision(player, player.getBoundingBox().move(0.0, (double)(-player.maxUpStep()), e))) {
                            if (e < 0.05 && e >= -0.05) {
                                e = 0.0;
                            } else if (e > 0.0) {
                                e -= 0.05;
                            } else {
                                e += 0.05;
                            }
                        }

                        while (d != 0.0 && e != 0.0 && player.level().noCollision(player, player.getBoundingBox().move(d, (double)(-player.maxUpStep()), e))) {
                            if (d < 0.05 && d >= -0.05) {
                                d = 0.0;
                            } else if (d > 0.0) {
                                d -= 0.05;
                            } else {
                                d += 0.05;
                            }

                            if (e < 0.05 && e >= -0.05) {
                                e = 0.0;
                            } else if (e > 0.0) {
                                e -= 0.05;
                            } else {
                                e += 0.05;
                            }
                        }

                        return new net.minecraft.world.phys.Vec3(d, vec.y, e);
                    }
                }
            }
        }
        return vec;
    }
}
