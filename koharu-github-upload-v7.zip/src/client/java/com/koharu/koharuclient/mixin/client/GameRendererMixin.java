package com.koharu.koharuclient.mixin.client;

import com.koharu.koharuclient.client.KoharuClient;
import com.koharu.koharuclient.client.module.impl.RenderOptimizer;
import com.koharu.koharuclient.client.setting.Setting;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
public class GameRendererMixin {

    private int itemActivationTicks;

    @Inject(method = "tick", at = @At("HEAD"))
    private void onTick(CallbackInfo ci) {
        if (RenderOptimizer.INSTANCE != null && RenderOptimizer.INSTANCE.isToggled()) {
            Setting fastTotem = KoharuClient.INSTANCE.settingsManager.getSettingByName(RenderOptimizer.INSTANCE, "Fast Totem Anim");
            if (fastTotem != null && fastTotem.getValBoolean()) {
                if (this.itemActivationTicks > 0) {
                    this.itemActivationTicks -= 2;
                    if (this.itemActivationTicks < 0) this.itemActivationTicks = 0;
                }
            }
        }
    }

    @Inject(method = "displayItemActivation", at = @At("HEAD"), cancellable = true)
    private void onDisplayItemActivation(net.minecraft.world.item.ItemStack stack, CallbackInfo ci) {
        if (stack == null || !stack.is(net.minecraft.world.item.Items.TOTEM_OF_UNDYING)) return;
        if (KoharuClient.INSTANCE == null || KoharuClient.INSTANCE.moduleManager == null) return;

        com.koharu.koharuclient.client.module.Module noTotemPop = KoharuClient.INSTANCE.moduleManager.getModule("NoTotemPop");
        if (noTotemPop != null && noTotemPop.isToggled()) {
            ci.cancel();
        }
    }

    @Inject(method = "bobHurt", at = @At("HEAD"), cancellable = true)
    private void onBobHurt(PoseStack poseStack, float partialTick, CallbackInfo ci) {
        if (RenderOptimizer.INSTANCE != null && RenderOptimizer.INSTANCE.isToggled()) {
            Setting noHurtCam = KoharuClient.INSTANCE.settingsManager.getSettingByName(RenderOptimizer.INSTANCE, "No Hurt Cam");
            if (noHurtCam != null && noHurtCam.getValBoolean()) {
                ci.cancel();
            }
        }
    }

}
