package com.koharu.koharuclient.mixin.client;

import com.koharu.koharuclient.client.KoharuClient;
import com.koharu.koharuclient.client.module.Module;
import net.minecraft.client.gui.screens.inventory.AbstractSignEditScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(AbstractSignEditScreen.class)
public class AutoSignScreenMixin {
    @Inject(method = "init", at = @At("HEAD"))
    private void onInit(CallbackInfo ci) {
        if (KoharuClient.INSTANCE != null && KoharuClient.INSTANCE.moduleManager != null) {
            Module autoSign = KoharuClient.INSTANCE.moduleManager.getModule("AutoSign");
            if (autoSign != null && autoSign.isToggled()) {
                com.koharu.koharuclient.client.module.impl.AutoSign.handleScreen((AbstractSignEditScreen)(Object)this);
            }
        }
    }
}