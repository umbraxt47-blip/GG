package com.koharu.koharuclient.mixin.client;

import com.koharu.koharuclient.client.KoharuClient;
import com.koharu.koharuclient.client.module.Module;
import com.koharu.koharuclient.client.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.PlayerTabOverlay;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.contents.PlainTextContents;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PlayerTabOverlay.class)
public class PlayerTabOverlayMixin {

    @Inject(method = "getNameForDisplay", at = @At("RETURN"), cancellable = true)
    private void onGetNameForDisplay(PlayerInfo playerInfo, CallbackInfoReturnable<Component> cir) {
        Module np = KoharuClient.INSTANCE.moduleManager.getModule("NameProtect");
        if (np != null && np.isToggled() && Minecraft.getInstance().getUser() != null) {
            String myName = Minecraft.getInstance().getUser().getName();
            
if (playerInfo.getProfile().name().equals(myName)) {
Component current = cir.getReturnValue();
Setting nameSetting = KoharuClient.INSTANCE.settingsManager.getSettingByName(np, "Name");
                String alias = nameSetting != null ? nameSetting.getValString() : "Koharu";

                if (current == null) {
                    cir.setReturnValue(Component.literal(alias));
                } else if (current.getString().contains(myName)) {
                    cir.setReturnValue(replaceName(current, myName, alias));
                }
            }
        }
    }

    private Component replaceName(Component original, String target, String replacement) {
        if (original == null) return null;

        MutableComponent newComponent;
        if (original.getContents() instanceof PlainTextContents) {
            PlainTextContents plainText = (PlainTextContents) original.getContents();
            String text = plainText.text();
            if (text.contains(target)) {
                newComponent = Component.literal(text.replace(target, replacement));
            } else {
                newComponent = original.plainCopy();
            }
        } else {
            newComponent = original.plainCopy();
        }

        newComponent.setStyle(original.getStyle());

        for (Component sibling : original.getSiblings()) {
            newComponent.append(replaceName(sibling, target, replacement));
        }

        return newComponent;
    }
}