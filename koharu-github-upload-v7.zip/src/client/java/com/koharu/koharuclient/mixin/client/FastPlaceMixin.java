package com.koharu.koharuclient.mixin.client;

import com.koharu.koharuclient.client.KoharuClient;
import com.koharu.koharuclient.client.module.impl.FastPlace;
import com.koharu.koharuclient.client.setting.Setting;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Minecraft.class)
public class FastPlaceMixin {

    @Shadow private int rightClickDelay;

    @Inject(method = "tick", at = @At("HEAD"))
    private void onTick(CallbackInfo ci) {
        if (FastPlace.INSTANCE != null && FastPlace.INSTANCE.isToggled()) {
            Setting delaySetting = KoharuClient.INSTANCE.settingsManager.getSettingByName(FastPlace.INSTANCE, "Delay (Ticks)");
            int targetDelay = delaySetting != null ? (int) delaySetting.getValDouble() : 0;
            
            if (this.rightClickDelay > targetDelay) {
                this.rightClickDelay = targetDelay;
            }
        }
    }
}