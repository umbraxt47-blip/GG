package com.koharu.koharuclient.mixin.client;

import com.koharu.koharuclient.client.KoharuClient;
import com.koharu.koharuclient.client.module.impl.RenderOptimizer;
import com.koharu.koharuclient.client.setting.Setting;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.scores.Objective;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Gui.class)
public class GuiMixin {

    @Inject(method = "displayScoreboardSidebar", at = @At("HEAD"), cancellable = true)
    private void onDisplayScoreboardSidebar(GuiGraphics guiGraphics, Objective objective, CallbackInfo ci) {
        if (RenderOptimizer.INSTANCE != null && RenderOptimizer.INSTANCE.isToggled()) {
            Setting noScoreboard = KoharuClient.INSTANCE.settingsManager.getSettingByName(RenderOptimizer.INSTANCE, "No Scoreboard");
            if (noScoreboard != null && noScoreboard.getValBoolean()) {
                ci.cancel();
            }
        }
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void onExtractRenderState(GuiGraphics guiGraphics, DeltaTracker tickDelta, CallbackInfo ci) {
        if (KoharuClient.INSTANCE != null && KoharuClient.INSTANCE.moduleManager != null) {
            for (com.koharu.koharuclient.client.module.Module m : KoharuClient.INSTANCE.moduleManager.modules) {
                if (m.isToggled()) {
                    m.onRenderHUD(guiGraphics, tickDelta);
                }
            }
        }
        com.koharu.koharuclient.client.ui.ArrayListHud.INSTANCE.render(guiGraphics, tickDelta.getGameTimeDeltaTicks());
    }
}
