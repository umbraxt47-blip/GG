package com.koharu.koharuclient.mixin.client;

import com.koharu.koharuclient.client.KoharuClient;
import com.koharu.koharuclient.client.module.impl.ESP;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.resources.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

@Mixin(LevelRenderer.class)
public class LevelRendererMixin {

    @ModifyArg(method = "renderLevel", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/ShaderManager;getPostChain(Lnet/minecraft/resources/Identifier;Ljava/util/Set;)Lnet/minecraft/client/renderer/PostChain;"), index = 0)
    private Identifier swapOutlineChain(Identifier id) {
        if (KoharuClient.INSTANCE == null || KoharuClient.INSTANCE.moduleManager == null) return id;
        if (KoharuClient.INSTANCE.moduleManager.getModule("ESP") instanceof ESP esp && esp.isShaderMode()) {
            return esp.getShaderChainId();
        }
        if (com.koharu.koharuclient.client.module.impl.SelfShader.INSTANCE != null
                && com.koharu.koharuclient.client.module.impl.SelfShader.INSTANCE.body()) {
            return com.koharu.koharuclient.client.module.impl.SelfShader.INSTANCE.shaderChainId();
        }
        return id;
    }
}
