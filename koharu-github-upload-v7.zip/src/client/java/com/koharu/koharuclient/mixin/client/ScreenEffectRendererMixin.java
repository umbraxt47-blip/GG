package com.koharu.koharuclient.mixin.client;

import com.koharu.koharuclient.client.KoharuClient;
import com.koharu.koharuclient.client.module.Module;
import com.koharu.koharuclient.client.module.impl.RenderOptimizer;
import com.koharu.koharuclient.client.setting.Setting;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.ScreenEffectRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ScreenEffectRenderer.class)
public class ScreenEffectRendererMixin {

    @Inject(method = "renderFire", at = @At("HEAD"), cancellable = true)
    private static void onRenderFire(PoseStack poseStack, MultiBufferSource buffer, TextureAtlasSprite textureAtlasSprite, CallbackInfo ci) {
        if (KoharuClient.INSTANCE != null && KoharuClient.INSTANCE.moduleManager != null) {
            Module lowFireModule = KoharuClient.INSTANCE.moduleManager.getModule("LowFire");
            if (lowFireModule != null && lowFireModule.isToggled()) {
                ci.cancel();
                return;
            }
        }

        if (RenderOptimizer.INSTANCE != null && RenderOptimizer.INSTANCE.isToggled()) {
            Setting lowFire = KoharuClient.INSTANCE.settingsManager.getSettingByName(RenderOptimizer.INSTANCE, "Low Fire");
            if (lowFire != null && lowFire.getValBoolean()) {
                poseStack.translate(0.0f, -0.3f, 0.0f);
            }
        }
    }
}
